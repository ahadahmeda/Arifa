package com.ahad.stakehelper

object Masaniello {
    // f[e][w] = শেষ ক্যাপিটাল গুণক: e ইভেন্ট বাকি, w জয় বাকি, কোটা q
    fun table(e: Int, w: Int, q: Double): Array<DoubleArray> {
        val f = Array(e + 1) { DoubleArray(w + 1) }
        for (i in 0..e) {
            f[i][0] = 1.0
            for (j in 1..w) {
                f[i][j] = when {
                    i < j -> 0.0
                    i == j -> Math.pow(q, j.toDouble())
                    else -> {
                        val a = f[i - 1][j - 1]
                        val b = f[i - 1][j]
                        val den = b + (q - 1.0) * a
                        if (den <= 0.0) 0.0 else q * a * b / den
                    }
                }
            }
        }
        return f
    }

    // পরের ট্রেডের স্টেক (শীটের algoritmo-র সূত্র, Normale মোড)
    fun stake(cash: Double, eLeft: Int, wLeft: Int, q: Double): Double {
        if (wLeft <= 0 || eLeft < wLeft || cash <= 0.0) return 0.0
        val f = table(eLeft, wLeft, q)
        val a = f[eLeft - 1][wLeft - 1]
        val b = f[eLeft - 1][wLeft]
        if (b <= 0.0) return cash
        val den = b + (q - 1.0) * a
        return cash * (1.0 - q * a / den)
    }
}
