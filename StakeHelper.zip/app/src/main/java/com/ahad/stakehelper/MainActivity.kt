package com.ahad.stakehelper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var cfg: Cfg
    private val fields = LinkedHashMap<String, EditText>()
    private lateinit var status: TextView
    private lateinit var stats: TextView

    private val refresher = object : Runnable {
        override fun run() {
            stats.text = TradeLog.stats(cfg)
            status.text = "শেষ দেখা অ্যাপ: ${Shared.lastPkg}\n\n${Shared.lastDump}"
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 13f
        v.setTextColor(Color.parseColor("#444444"))
        v.setPadding(0, dp(12), 0, dp(2))
        return v
    }

    private fun addField(root: LinearLayout, title: String, key: String, def: String, text: Boolean = false) {
        root.addView(label(title))
        val e = EditText(this)
        e.setText(cfg.s(key, def))
        e.inputType = if (text) InputType.TYPE_CLASS_TEXT
        else InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        root.addView(e)
        fields[key] = e
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(16))

        val title = TextView(this)
        title.text = "Stake Helper"
        title.textSize = 22f
        root.addView(title)

        val help = TextView(this)
        help.text = "১) নিচে সেটিং দিয়ে Save করুন।\n২) 'অ্যাক্সেসিবিলিটি চালু করুন' চেপে Stake Helper অন করুন।\n৩) Quotex (ডেমো অ্যাকাউন্ট) খুলুন, ওভারলের 📍Buy ও 📍Sell চেপে বাটন দুটো শেখান, তারপর ▶ AUTO চাপুন।\n৪) Quotex-এ 1 মিনিটের ক্যান্ডেল আগে থেকেই সেট করে রাখুন, আর ফোনের তারিখ-সময় \"অটোমেটিক\" রাখুন।"
        help.textSize = 13f
        root.addView(help)

        root.addView(label("📊 ডেমো ফলাফল (৩০০+ ট্রেডের পর জয়ের হার দেখে সিদ্ধান্ত নিন)"))
        stats = TextView(this)
        stats.textSize = 14f
        stats.setTextColor(Color.parseColor("#0D47A1"))
        root.addView(stats)

        val b1 = Button(this)
        b1.text = "অ্যাক্সেসিবিলিটি চালু করুন"
        b1.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(b1)

        addField(root, "ভার্চুয়াল ক্যাপিটাল (শীটের Capitale Iniziale)", "capital", "5500")
        addField(root, "মোট ইভেন্ট", "events", "17")
        addField(root, "আশা করা জয়", "expwins", "5")
        addField(root, "STOP লেভেল (ক্যাশ এর নিচে নামলে চক্র ক্লোজ; সাধারণত ক্যাপিটালের অর্ধেক)", "stop", (cfg.capital / 2).toString())
        addField(root, "ট্রেডের মেয়াদ (সেকেন্ড) — হার ধরতে লাগে", "expiry", "60")
        addField(root, "কোটা (শীটের মতো, স্টেক হিসাবে সবসময় এটা ব্যবহার হবে)", "quota", "1.89")
        addField(root, "ন্যূনতম পেআউট % (এর নিচে হলে ট্রেড করবে না)", "minpay", "88")
        addField(root, "নতুন সাইকেলের নিয়ম (ট্রেড:জয়, কমা দিয়ে। 1:1,5:2,8:3,11:4 = ১টায় ১ জয়, ৫টার মধ্যে ২ জয়, ৮টার মধ্যে ৩, ১১টার মধ্যে ৪)", "rules", "1:1,5:2,8:3,11:4", true)
        addField(root, "দিনের লাভের লক্ষ্য (এই পরিমাণ লাভ হলে সেদিন বন্ধ; 0 = বন্ধ; ডিফল্ট ক্যাপিটালের অর্ধেক)", "dailytarget", (cfg.capital / 2).toString())
        addField(root, "দিনে সর্বোচ্চ সফল সার্কেল (0 = সীমা নেই)", "maxcycles", "0")
        addField(root, "ট্রেড ক্যান্ডেল ক্লোজে শেষ হয়? (1 = হ্যাঁ, 0 = না, তখন মেয়াদ সেকেন্ড ব্যবহার হবে)", "candleclose", "1")
        addField(root, "ফোনের ঘড়ি ও Quotex ক্যান্ডেলের সেকেন্ডের ফারাক (সাধারণত 0)", "clockoffset", "0")
        addField(root, "ক্যান্ডেল শুরুর কত সেকেন্ডের মধ্যে বিশ্লেষণ শুরু করবে", "analyzestart", "6")
        addField(root, "ক্যান্ডেলের কত সেকেন্ডের মধ্যে ট্রেড নেওয়া যাবে (সেফটি সহ)", "entrywindow", "25")
        addField(root, "ক্লোজের কত সেকেন্ড পরে ফলাফল দেখা শুরু", "settle", "3")
        addField(root, "ব্যালেন্স না বাড়লে এআই দিয়ে স্ক্রিন দেখে ফলাফল যাচাই? (1 = হ্যাঁ, 0 = না)", "resultcheck", "1")
        addField(root, "ট্রেডের পর বিরতি (সেকেন্ড)", "cooldown", "3")
        addField(root, "শুধু ডেমোতে অটো-ট্রেড? (1 = হ্যাঁ, 0 = না)", "demoguard", "1")
        addField(root, "এআই (gemini বা claude)", "provider", "gemini", true)
        addField(root, "এআই API কী", "apikey", "", true)
        addField(root, "মডেলের নাম (ফাঁকা = ডিফল্ট)", "model", "", true)
        addField(root, "লক্ষ্য অ্যাপের প্যাকেজ-নামের অংশ (কমা দিয়ে; ফাঁকা = সব অ্যাপ)", "pkg", "qx,quotex", true)

        val save = Button(this)
        save.text = "Save"
        save.setOnClickListener {
            for ((k, e) in fields) cfg.put(k, e.text.toString().trim())
            Toast.makeText(this, "সেভ হয়েছে — ওভারলের ⟲ চেপে সাইকেল রিসেট করুন", Toast.LENGTH_LONG).show()
        }
        root.addView(save)

        val clr = Button(this)
        clr.text = "ফলাফলের লগ মুছুন"
        clr.setOnClickListener { cfg.put("log", ""); Toast.makeText(this, "লগ মুছেছে", Toast.LENGTH_SHORT).show() }
        root.addView(clr)

        root.addView(label("স্ক্রিন থেকে যা পড়ছে (সমস্যা হলে এটার স্ক্রিনশট পাঠান):"))
        status = TextView(this)
        status.textSize = 11f
        status.setTextColor(Color.parseColor("#1B5E20"))
        root.addView(status)

        val sv = ScrollView(this)
        sv.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        h.post(refresher)
    }

    override fun onPause() {
        h.removeCallbacks(refresher)
        super.onPause()
    }
}
