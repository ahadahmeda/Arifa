Stake Helper — Masaniello স্টেক অটো-ফিল (Quotex)

GitHub-এ নতুন রিপোজিটরি বানিয়ে এই ফোল্ডারের সব ফাইল (.github সহ) আপলোড করুন।
Actions ট্যাব -> Build APK -> Artifacts থেকে app-debug.apk নামান।
